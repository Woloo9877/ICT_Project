`timescale 1ns / 1ps

module alu(
    input [63:0] in_a,
    input [63:0] in_b,
    input [4:0] alu_control,
    output reg [63:0] result,
    output reg zero_flag,
    output reg negative_flag,
    output reg overflow_flag,
    output reg carry_flag
    );
    
    wire [64:0] add_result_with_carry;
    assign add_result_with_carry = {1'b0, in_a} + {1'b0, in_b};

    always @(*)
    begin
        // Default values
        result = 64'd0;
        zero_flag = 0;
        negative_flag = 0;
        overflow_flag = 0;
        carry_flag = 0;

        case(alu_control)
            // arthimetic
            5'b00000: result = {48'b0, in_a[15:0] + in_b[15:0]}; // add
            5'b00101: result = in_a + in_b; // addi
            5'b00110: result = in_b; // li (Load Immediate)
            5'b01101: result = {32'b0, in_a[15:0] * in_b[15:0]}; // mul (produces 32-bit result in lower half)

            // shift
            5'b00001: result = in_a << in_b[4:0]; // sll
            5'b00010: result = in_a >> in_b[4:0]; // slr

            //logical
            5'b00011: result = in_a | in_b; // or
            5'b00100: result = in_a & in_b; // and

            //SIMD Operations 
            5'b01111: begin // vadd
                result[15:0] = in_a[15:0] + in_b[15:0];
                result[31:16] = in_a[31:16] + in_b[31:16];
                result[47:32] = in_a[47:32] + in_b[47:32];
                result[63:48] = in_a[63:48] + in_b[63:48];
            end
            5'b10001: begin // vaddi
                result[15:0] = in_a[15:0] + in_b[15:0];
                result[31:16] = in_a[31:16] + in_b[15:0];
                result[47:32] = in_a[47:32] + in_b[15:0];
                result[63:48] = in_a[63:48] + in_b[15:0];
            end
            5'b10010: result = {in_b[15:0], in_b[15:0], in_b[15:0], in_b[15:0]}; // vli
            5'b10000: begin // vmul (2 parallel multiplies, result fits in 64 bits)
                result[31:0] = in_a[15:0] * in_b[15:0];
                result[63:32] = in_a[31:16] * in_b[31:16];
            end

            //Branch/Subtract
            5'b11111: result = in_a - in_b; // For BEQ/BEQZ flag generation

            default: result = 64'd0;
        endcase
        
        // Update Flag
        if (result == 0) zero_flag = 1;
        negative_flag = result[63];
        carry_flag = add_result_with_carry[64];
        if (in_a[63] == in_b[63] && result[63] != in_a[63]) overflow_flag = 1;
    end
endmodule