/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/vboxuser/Desktop/project/ictproject/register_file.v";
static int ng1[] = {0, 0};
static int ng2[] = {8, 0};
static unsigned int ng3[] = {0U, 0U, 0U, 0U};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {0U, 0U};
static int ng6[] = {15, 0};
static unsigned int ng7[] = {1U, 0U};
static int ng8[] = {31, 0};
static int ng9[] = {16, 0};
static unsigned int ng10[] = {2U, 0U};
static int ng11[] = {47, 0};
static int ng12[] = {32, 0};
static unsigned int ng13[] = {3U, 0U};
static int ng14[] = {63, 0};
static int ng15[] = {48, 0};



static void Cont_22_0(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 4288U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(22, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 3208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 3208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = (t0 + 1528U);
    t13 = *((char **)t12);
    xsi_vlog_generic_get_array_select_value(t5, 64, t4, t8, t11, 2, 1, t13, 3, 2);
    t12 = (t0 + 5216);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    xsi_vlog_bit_copy(t17, 0, t5, 0, 64);
    xsi_driver_vfirst_trans(t12, 0, 63);
    t18 = (t0 + 5104);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_23_1(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 4536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(23, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t6 = (t0 + 3208);
    t7 = (t6 + 72U);
    t8 = *((char **)t7);
    t9 = (t0 + 3208);
    t10 = (t9 + 64U);
    t11 = *((char **)t10);
    t12 = (t0 + 1688U);
    t13 = *((char **)t12);
    xsi_vlog_generic_get_array_select_value(t5, 64, t4, t8, t11, 2, 1, t13, 3, 2);
    t12 = (t0 + 5280);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    xsi_vlog_bit_copy(t17, 0, t5, 0, 64);
    xsi_driver_vfirst_trans(t12, 0, 63);
    t18 = (t0 + 5120);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_25_2(char *t0)
{
    char t13[8];
    char t15[8];
    char t16[8];
    char t39[8];
    char t40[8];
    char t41[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    int t28;
    char *t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    int t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    char *t42;
    char *t43;
    char *t44;
    unsigned int t45;
    char *t46;
    unsigned int t47;
    char *t48;
    unsigned int t49;
    int t50;
    char *t51;
    unsigned int t52;
    int t53;
    int t54;
    char *t55;
    unsigned int t56;
    int t57;
    int t58;
    unsigned int t59;
    int t60;
    unsigned int t61;
    unsigned int t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    int t66;
    int t67;

LAB0:    t1 = (t0 + 4784U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 5136);
    *((int *)t2) = 1;
    t3 = (t0 + 4816);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(26, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB16;

LAB17:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 2488U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB22;

LAB23:
LAB24:
LAB18:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(27, ng0);

LAB9:    xsi_set_current_line(28, ng0);
    xsi_set_current_line(28, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3368);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 32);

LAB10:    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t13, 0, 8);
    xsi_vlog_signed_less(t13, 32, t4, 32, t5, 32);
    t11 = (t13 + 4);
    t6 = *((unsigned int *)t11);
    t7 = (~(t6));
    t8 = *((unsigned int *)t13);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB11;

LAB12:    goto LAB8;

LAB11:    xsi_set_current_line(28, ng0);

LAB13:    xsi_set_current_line(29, ng0);
    t12 = ((char*)((ng3)));
    t14 = (t0 + 3208);
    t17 = (t0 + 3208);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 3208);
    t21 = (t20 + 64U);
    t22 = *((char **)t21);
    t23 = (t0 + 3368);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    xsi_vlog_generic_convert_array_indices(t15, t16, t19, t22, 2, 1, t25, 32, 1);
    t26 = (t15 + 4);
    t27 = *((unsigned int *)t26);
    t28 = (!(t27));
    t29 = (t16 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (!(t30));
    t32 = (t28 && t31);
    if (t32 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t13, 0, 8);
    xsi_vlog_signed_add(t13, 32, t4, 32, t5, 32);
    t11 = (t0 + 3368);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 32);
    goto LAB10;

LAB14:    t33 = *((unsigned int *)t15);
    t34 = *((unsigned int *)t16);
    t35 = (t33 - t34);
    t36 = (t35 + 1);
    xsi_vlogvar_wait_assign_value(t14, t12, 0, *((unsigned int *)t16), t36, 0LL);
    goto LAB15;

LAB16:    xsi_set_current_line(32, ng0);

LAB19:    xsi_set_current_line(33, ng0);
    t4 = (t0 + 2008U);
    t5 = *((char **)t4);
    t4 = (t0 + 3208);
    t11 = (t0 + 3208);
    t12 = (t11 + 72U);
    t14 = *((char **)t12);
    t17 = (t0 + 3208);
    t18 = (t17 + 64U);
    t19 = *((char **)t18);
    t20 = (t0 + 1848U);
    t21 = *((char **)t20);
    xsi_vlog_generic_convert_array_indices(t13, t15, t14, t19, 2, 1, t21, 3, 2);
    t20 = (t13 + 4);
    t27 = *((unsigned int *)t20);
    t28 = (!(t27));
    t22 = (t15 + 4);
    t30 = *((unsigned int *)t22);
    t31 = (!(t30));
    t32 = (t28 && t31);
    if (t32 == 1)
        goto LAB20;

LAB21:    goto LAB18;

LAB20:    t33 = *((unsigned int *)t13);
    t34 = *((unsigned int *)t15);
    t35 = (t33 - t34);
    t36 = (t35 + 1);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, *((unsigned int *)t15), t36, 0LL);
    goto LAB21;

LAB22:    xsi_set_current_line(36, ng0);

LAB25:    xsi_set_current_line(37, ng0);
    t4 = (t0 + 2648U);
    t5 = *((char **)t4);

LAB26:    t4 = ((char*)((ng5)));
    t28 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t28 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng7)));
    t28 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t28 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng10)));
    t28 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t28 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng13)));
    t28 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t28 == 1)
        goto LAB33;

LAB34:
LAB35:    goto LAB24;

LAB27:    xsi_set_current_line(38, ng0);
    t11 = (t0 + 2808U);
    t12 = *((char **)t11);
    memset(t13, 0, 8);
    t11 = (t13 + 4);
    t14 = (t12 + 4);
    t27 = *((unsigned int *)t12);
    t30 = (t27 >> 0);
    *((unsigned int *)t13) = t30;
    t33 = *((unsigned int *)t14);
    t34 = (t33 >> 0);
    *((unsigned int *)t11) = t34;
    t37 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t37 & 65535U);
    t38 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t38 & 65535U);
    t17 = (t0 + 3208);
    t18 = (t0 + 3208);
    t19 = (t18 + 72U);
    t20 = *((char **)t19);
    t21 = (t0 + 3208);
    t22 = (t21 + 64U);
    t23 = *((char **)t22);
    t24 = (t0 + 1848U);
    t25 = *((char **)t24);
    xsi_vlog_generic_convert_array_indices(t15, t16, t20, t23, 2, 1, t25, 3, 2);
    t24 = (t0 + 3208);
    t26 = (t24 + 72U);
    t29 = *((char **)t26);
    t42 = ((char*)((ng6)));
    t43 = ((char*)((ng1)));
    xsi_vlog_convert_partindices(t39, t40, t41, ((int*)(t29)), 2, t42, 32, 1, t43, 32, 1);
    t44 = (t15 + 4);
    t45 = *((unsigned int *)t44);
    t31 = (!(t45));
    t46 = (t16 + 4);
    t47 = *((unsigned int *)t46);
    t32 = (!(t47));
    t35 = (t31 && t32);
    t48 = (t39 + 4);
    t49 = *((unsigned int *)t48);
    t36 = (!(t49));
    t50 = (t35 && t36);
    t51 = (t40 + 4);
    t52 = *((unsigned int *)t51);
    t53 = (!(t52));
    t54 = (t50 && t53);
    t55 = (t41 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (!(t56));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB36;

LAB37:    goto LAB35;

LAB29:    xsi_set_current_line(39, ng0);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 0);
    *((unsigned int *)t3) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 65535U);
    t27 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t27 & 65535U);
    t12 = (t0 + 3208);
    t14 = (t0 + 3208);
    t17 = (t14 + 72U);
    t18 = *((char **)t17);
    t19 = (t0 + 3208);
    t20 = (t19 + 64U);
    t21 = *((char **)t20);
    t22 = (t0 + 1848U);
    t23 = *((char **)t22);
    xsi_vlog_generic_convert_array_indices(t15, t16, t18, t21, 2, 1, t23, 3, 2);
    t22 = (t0 + 3208);
    t24 = (t22 + 72U);
    t25 = *((char **)t24);
    t26 = ((char*)((ng8)));
    t29 = ((char*)((ng9)));
    xsi_vlog_convert_partindices(t39, t40, t41, ((int*)(t25)), 2, t26, 32, 1, t29, 32, 1);
    t42 = (t15 + 4);
    t30 = *((unsigned int *)t42);
    t31 = (!(t30));
    t43 = (t16 + 4);
    t33 = *((unsigned int *)t43);
    t32 = (!(t33));
    t35 = (t31 && t32);
    t44 = (t39 + 4);
    t34 = *((unsigned int *)t44);
    t36 = (!(t34));
    t50 = (t35 && t36);
    t46 = (t40 + 4);
    t37 = *((unsigned int *)t46);
    t53 = (!(t37));
    t54 = (t50 && t53);
    t48 = (t41 + 4);
    t38 = *((unsigned int *)t48);
    t57 = (!(t38));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB38;

LAB39:    goto LAB35;

LAB31:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 0);
    *((unsigned int *)t3) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 65535U);
    t27 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t27 & 65535U);
    t12 = (t0 + 3208);
    t14 = (t0 + 3208);
    t17 = (t14 + 72U);
    t18 = *((char **)t17);
    t19 = (t0 + 3208);
    t20 = (t19 + 64U);
    t21 = *((char **)t20);
    t22 = (t0 + 1848U);
    t23 = *((char **)t22);
    xsi_vlog_generic_convert_array_indices(t15, t16, t18, t21, 2, 1, t23, 3, 2);
    t22 = (t0 + 3208);
    t24 = (t22 + 72U);
    t25 = *((char **)t24);
    t26 = ((char*)((ng11)));
    t29 = ((char*)((ng12)));
    xsi_vlog_convert_partindices(t39, t40, t41, ((int*)(t25)), 2, t26, 32, 1, t29, 32, 1);
    t42 = (t15 + 4);
    t30 = *((unsigned int *)t42);
    t31 = (!(t30));
    t43 = (t16 + 4);
    t33 = *((unsigned int *)t43);
    t32 = (!(t33));
    t35 = (t31 && t32);
    t44 = (t39 + 4);
    t34 = *((unsigned int *)t44);
    t36 = (!(t34));
    t50 = (t35 && t36);
    t46 = (t40 + 4);
    t37 = *((unsigned int *)t46);
    t53 = (!(t37));
    t54 = (t50 && t53);
    t48 = (t41 + 4);
    t38 = *((unsigned int *)t48);
    t57 = (!(t38));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB40;

LAB41:    goto LAB35;

LAB33:    xsi_set_current_line(41, ng0);
    t3 = (t0 + 2808U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t3 = (t13 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t13) = t7;
    t8 = *((unsigned int *)t11);
    t9 = (t8 >> 0);
    *((unsigned int *)t3) = t9;
    t10 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t10 & 65535U);
    t27 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t27 & 65535U);
    t12 = (t0 + 3208);
    t14 = (t0 + 3208);
    t17 = (t14 + 72U);
    t18 = *((char **)t17);
    t19 = (t0 + 3208);
    t20 = (t19 + 64U);
    t21 = *((char **)t20);
    t22 = (t0 + 1848U);
    t23 = *((char **)t22);
    xsi_vlog_generic_convert_array_indices(t15, t16, t18, t21, 2, 1, t23, 3, 2);
    t22 = (t0 + 3208);
    t24 = (t22 + 72U);
    t25 = *((char **)t24);
    t26 = ((char*)((ng14)));
    t29 = ((char*)((ng15)));
    xsi_vlog_convert_partindices(t39, t40, t41, ((int*)(t25)), 2, t26, 32, 1, t29, 32, 1);
    t42 = (t15 + 4);
    t30 = *((unsigned int *)t42);
    t31 = (!(t30));
    t43 = (t16 + 4);
    t33 = *((unsigned int *)t43);
    t32 = (!(t33));
    t35 = (t31 && t32);
    t44 = (t39 + 4);
    t34 = *((unsigned int *)t44);
    t36 = (!(t34));
    t50 = (t35 && t36);
    t46 = (t40 + 4);
    t37 = *((unsigned int *)t46);
    t53 = (!(t37));
    t54 = (t50 && t53);
    t48 = (t41 + 4);
    t38 = *((unsigned int *)t48);
    t57 = (!(t38));
    t58 = (t54 && t57);
    if (t58 == 1)
        goto LAB42;

LAB43:    goto LAB35;

LAB36:    t59 = *((unsigned int *)t41);
    t60 = (t59 + 0);
    t61 = *((unsigned int *)t16);
    t62 = *((unsigned int *)t40);
    t63 = (t61 + t62);
    t64 = *((unsigned int *)t39);
    t65 = *((unsigned int *)t40);
    t66 = (t64 - t65);
    t67 = (t66 + 1);
    xsi_vlogvar_wait_assign_value(t17, t13, t60, t63, t67, 0LL);
    goto LAB37;

LAB38:    t45 = *((unsigned int *)t41);
    t60 = (t45 + 0);
    t47 = *((unsigned int *)t16);
    t49 = *((unsigned int *)t40);
    t63 = (t47 + t49);
    t52 = *((unsigned int *)t39);
    t56 = *((unsigned int *)t40);
    t66 = (t52 - t56);
    t67 = (t66 + 1);
    xsi_vlogvar_wait_assign_value(t12, t13, t60, t63, t67, 0LL);
    goto LAB39;

LAB40:    t45 = *((unsigned int *)t41);
    t60 = (t45 + 0);
    t47 = *((unsigned int *)t16);
    t49 = *((unsigned int *)t40);
    t63 = (t47 + t49);
    t52 = *((unsigned int *)t39);
    t56 = *((unsigned int *)t40);
    t66 = (t52 - t56);
    t67 = (t66 + 1);
    xsi_vlogvar_wait_assign_value(t12, t13, t60, t63, t67, 0LL);
    goto LAB41;

LAB42:    t45 = *((unsigned int *)t41);
    t60 = (t45 + 0);
    t47 = *((unsigned int *)t16);
    t49 = *((unsigned int *)t40);
    t63 = (t47 + t49);
    t52 = *((unsigned int *)t39);
    t56 = *((unsigned int *)t40);
    t66 = (t52 - t56);
    t67 = (t66 + 1);
    xsi_vlogvar_wait_assign_value(t12, t13, t60, t63, t67, 0LL);
    goto LAB43;

}


extern void work_m_00000000001750787896_0278921292_init()
{
	static char *pe[] = {(void *)Cont_22_0,(void *)Cont_23_1,(void *)Always_25_2};
	xsi_register_didat("work_m_00000000001750787896_0278921292", "isim/testbench_isim_beh.exe.sim/work/m_00000000001750787896_0278921292.didat");
	xsi_register_executes(pe);
}
