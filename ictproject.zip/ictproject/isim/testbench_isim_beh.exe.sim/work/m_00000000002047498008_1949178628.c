/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "Time=%0t ns, PC=%d, R1=%d, R2=%d, R3=%d, R4=%d, R5=%x, R6=%x, Hi=%d, Lo=%d, SR=%b";
static int ng1[] = {1, 0};
static int ng2[] = {2, 0};
static int ng3[] = {3, 0};
static int ng4[] = {4, 0};
static int ng5[] = {5, 0};
static int ng6[] = {6, 0};
static const char *ng7 = "C:/Users/vboxuser/Desktop/project/ictproject/testbench.v";
static int ng8[] = {0, 0};

void Monitor_18_2(char *);
void Monitor_18_2(char *);


static void Monitor_18_2_Func(char *t0)
{
    char t1[16];
    char t11[16];
    char t25[16];
    char t39[16];
    char t53[16];
    char t67[16];
    char t81[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;

LAB0:    t2 = xsi_vlog_time(t1, 1000.0000000000000, 1000.0000000000000);
    t3 = (t0 + 4952);
    t4 = *((char **)t3);
    t5 = ((((char*)(t4))) + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 4984);
    t8 = *((char **)t7);
    t9 = ((((char*)(t8))) + 56U);
    t10 = *((char **)t9);
    t12 = (t0 + 5016);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 72U);
    t15 = *((char **)t14);
    t16 = (t0 + 5048);
    t17 = *((char **)t16);
    t18 = ((((char*)(t17))) + 64U);
    t19 = *((char **)t18);
    t20 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t11, 64, t10, t15, t19, 2, 1, t20, 32, 1);
    t21 = (t0 + 5080);
    t22 = *((char **)t21);
    t23 = ((((char*)(t22))) + 56U);
    t24 = *((char **)t23);
    t26 = (t0 + 5112);
    t27 = *((char **)t26);
    t28 = ((((char*)(t27))) + 72U);
    t29 = *((char **)t28);
    t30 = (t0 + 5144);
    t31 = *((char **)t30);
    t32 = ((((char*)(t31))) + 64U);
    t33 = *((char **)t32);
    t34 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t25, 64, t24, t29, t33, 2, 1, t34, 32, 1);
    t35 = (t0 + 5176);
    t36 = *((char **)t35);
    t37 = ((((char*)(t36))) + 56U);
    t38 = *((char **)t37);
    t40 = (t0 + 5208);
    t41 = *((char **)t40);
    t42 = ((((char*)(t41))) + 72U);
    t43 = *((char **)t42);
    t44 = (t0 + 5240);
    t45 = *((char **)t44);
    t46 = ((((char*)(t45))) + 64U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t39, 64, t38, t43, t47, 2, 1, t48, 32, 1);
    t49 = (t0 + 5272);
    t50 = *((char **)t49);
    t51 = ((((char*)(t50))) + 56U);
    t52 = *((char **)t51);
    t54 = (t0 + 5304);
    t55 = *((char **)t54);
    t56 = ((((char*)(t55))) + 72U);
    t57 = *((char **)t56);
    t58 = (t0 + 5336);
    t59 = *((char **)t58);
    t60 = ((((char*)(t59))) + 64U);
    t61 = *((char **)t60);
    t62 = ((char*)((ng4)));
    xsi_vlog_generic_get_array_select_value(t53, 64, t52, t57, t61, 2, 1, t62, 32, 1);
    t63 = (t0 + 5368);
    t64 = *((char **)t63);
    t65 = ((((char*)(t64))) + 56U);
    t66 = *((char **)t65);
    t68 = (t0 + 5400);
    t69 = *((char **)t68);
    t70 = ((((char*)(t69))) + 72U);
    t71 = *((char **)t70);
    t72 = (t0 + 5432);
    t73 = *((char **)t72);
    t74 = ((((char*)(t73))) + 64U);
    t75 = *((char **)t74);
    t76 = ((char*)((ng5)));
    xsi_vlog_generic_get_array_select_value(t67, 64, t66, t71, t75, 2, 1, t76, 32, 1);
    t77 = (t0 + 5464);
    t78 = *((char **)t77);
    t79 = ((((char*)(t78))) + 56U);
    t80 = *((char **)t79);
    t82 = (t0 + 5496);
    t83 = *((char **)t82);
    t84 = ((((char*)(t83))) + 72U);
    t85 = *((char **)t84);
    t86 = (t0 + 5528);
    t87 = *((char **)t86);
    t88 = ((((char*)(t87))) + 64U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng6)));
    xsi_vlog_generic_get_array_select_value(t81, 64, t80, t85, t89, 2, 1, t90, 32, 1);
    t91 = (t0 + 5552);
    t92 = *((char **)t91);
    t93 = ((((char*)(t92))) + 56U);
    t94 = *((char **)t93);
    t95 = (t0 + 5576);
    t96 = *((char **)t95);
    t97 = ((((char*)(t96))) + 56U);
    t98 = *((char **)t97);
    t99 = (t0 + 5600);
    t100 = *((char **)t99);
    t101 = ((((char*)(t100))) + 56U);
    t102 = *((char **)t101);
    xsi_vlogfile_write(1, 0, 3, ng0, 12, t0, (char)118, t1, 64, (char)118, t6, 8, (char)118, t11, 64, (char)118, t25, 64, (char)118, t39, 64, (char)118, t53, 64, (char)118, t67, 64, (char)118, t81, 64, (char)118, t94, 64, (char)118, t98, 64, (char)118, t102, 4);

LAB1:    return;
}

static void Initial_8_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 2368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(8, ng7);

LAB4:    xsi_set_current_line(9, ng7);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1288);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(10, ng7);

LAB5:    xsi_set_current_line(10, ng7);
    t2 = (t0 + 2176);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(10, ng7);
    t3 = (t0 + 1288);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 1288);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_13_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 2616U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(13, ng7);

LAB4:    xsi_set_current_line(14, ng7);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(15, ng7);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 25000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(16, ng7);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(18, ng7);
    Monitor_18_2(t0);
    xsi_set_current_line(23, ng7);
    t2 = (t0 + 2424);
    xsi_process_wait(t2, 200000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(24, ng7);
    xsi_vlog_finish(1);
    goto LAB1;

}

void Monitor_18_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2672);
    t2 = (t0 + 3184);
    xsi_vlogfile_monitor((void *)Monitor_18_2_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000002047498008_1949178628_init()
{
	static char *pe[] = {(void *)Initial_8_0,(void *)Initial_13_1,(void *)Monitor_18_2};
	xsi_register_didat("work_m_00000000002047498008_1949178628", "isim/testbench_isim_beh.exe.sim/work/m_00000000002047498008_1949178628.didat");
	xsi_register_executes(pe);
}
