`timescale 1ns / 1ps

module control_unit(
    input [4:0] opcode,
    output reg reg_write,
    output reg mem_to_reg,
    output reg mem_read,
    output reg mem_write,
    output reg [4:0] alu_op,
    output reg alu_src,
    output reg write_hi_lo,
    output reg mflo_en,
    output reg mfhi_en,
    output reg update_sr,
    output reg jump_en,
    output reg lane_write_en // New signal for VLW
    );

    always @(*)
    begin
        reg_write = 0; mem_to_reg = 0; mem_read = 0; mem_write = 0; alu_op = 5'b0;
        alu_src = 0; write_hi_lo = 0; mflo_en = 0; mfhi_en = 0; update_sr = 0; jump_en = 0; lane_write_en = 0;

        case(opcode)
            5'b00000, 5'b00001, 5'b00010, 5'b00011, 5'b00100:
                begin reg_write = 1; alu_op = opcode; update_sr = 1; end
            5'b00101, 5'b00110:
                begin reg_write = 1; alu_src = 1; alu_op = opcode; update_sr = 1; end
            5'b00111:
                begin reg_write = 1; alu_src = 1; mem_read = 1; mem_to_reg = 1; alu_op = 5'b00101; end
            5'b01000:
                begin alu_src = 1; mem_write = 1; alu_op = 5'b00101; end
            5'b01001: begin jump_en = 1; end
            5'b01011, 5'b01010:
                begin alu_op = 5'b11111; update_sr = 1; end
            5'b01101: begin write_hi_lo = 1; alu_op = opcode; end
            5'b01100: begin reg_write = 1; mfhi_en = 1; end
            5'b01110: begin reg_write = 1; mflo_en = 1; end
            5'b01111, 5'b10001, 5'b10010, 5'b10000:
                begin reg_write = 1; alu_op = opcode; update_sr = 1; alu_src = (opcode != 5'b01111 && opcode != 5'b10000); end
            5'b10011: // vlw
                begin lane_write_en = 1; alu_src = 1; mem_read = 1; alu_op = 5'b00101; end
        endcase
    end
endmodule