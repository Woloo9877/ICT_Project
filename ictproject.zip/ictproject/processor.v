`timescale 1ns / 1ps

module processor(
    input clk,
    input reset
    );

    // Special Purpose Registers
    reg [63:0] hi_reg, lo_reg;
    reg [3:0] status_reg; // {Overflow, Carry, Negative, Zero}

    // Program Counter
    reg [7:0] pc;
    wire [7:0] pc_next;
    wire [7:0] pc_plus_1 = pc + 1;
    wire [11:0] jump_addr = instruction[11:0];

    // Instruction Fetch & Decode
    wire [19:0] instruction;
    instruction_memory i_mem (.address(pc), .instruction(instruction));
    wire [4:0] opcode = instruction[19:15];
    wire [2:0] rd_addr = instruction[14:12];
    wire [2:0] rs_addr = instruction[11:9];
    wire [2:0] rt_addr = instruction[8:6];
    wire [8:0] i_imm = instruction[8:0];
    wire [1:0] lane_id = instruction[19:18]; // For VLW instruction
    wire [63:0] sign_extended_imm = {{55{i_imm[8]}}, i_imm};
    
    // Control Unit Instantiation
    wire reg_write, mem_to_reg, mem_read, mem_write, alu_src, write_hi_lo, mflo_en, mfhi_en, update_sr, jump_en, lane_write_en;
    wire [4:0] alu_op;
    control_unit ctrl( .opcode(opcode), .reg_write(reg_write), .mem_to_reg(mem_to_reg), .mem_read(mem_read), .mem_write(mem_write), .alu_op(alu_op), .alu_src(alu_src), .write_hi_lo(write_hi_lo), .mflo_en(mflo_en), .mfhi_en(mfhi_en), .update_sr(update_sr), .jump_en(jump_en), .lane_write_en(lane_write_en) );

    // Register File Instantiation
    wire [63:0] rs_data, rt_data;
    register_file rf( .clk(clk), .reset(reset), .reg_write_en(reg_write), .read_addr1(rs_addr), .read_addr2(rt_addr), .write_addr(rd_addr), .write_data(write_back_data), .read_data1(rs_data), .read_data2(rt_data), .lane_write_en(lane_write_en), .lane_id(lane_id), .mem_data_in({48'b0, mem_read_data}) );

    // alu
    wire [63:0] alu_in_b = alu_src ? sign_extended_imm : rt_data;
    wire [63:0] alu_result;
    wire zero_f, neg_f, carry_f, overflow_f;
    alu my_alu( .in_a(rs_data), .in_b(alu_in_b), .alu_control(alu_op), .result(alu_result), .zero_flag(zero_f), .negative_flag(neg_f), .carry_flag(carry_f), .overflow_flag(overflow_f) );

    // Data Memory Instantiation
    wire [15:0] mem_read_data;
    data_memory d_mem( .clk(clk), .mem_write_en(mem_write), .mem_read_en(mem_read), .address(alu_result[15:0]), .write_data(rt_data[15:0]), .read_data(mem_read_data) );

    // Write Back Data Path
    wire [63:0] write_back_data;
    assign write_back_data = mflo_en ? lo_reg : mfhi_en ? hi_reg : mem_to_reg ? {48'b0, mem_read_data} : alu_result;

    // PC Update Logic
    wire branch_beq = (opcode == 5'b01011) & zero_f;
    wire branch_beqz = (opcode == 5'b01010) & (rs_data == 0);
    wire branch_active = branch_beq | branch_beqz;
    assign pc_next = jump_en ? jump_addr[7:0] :
                     branch_active ? (pc_plus_1 + sign_extended_imm) : // Branch uses sign-extended offset
                     pc_plus_1;
    
    // Main sequential block for state updates
    always @(posedge clk or posedge reset)
    begin
        if (reset) begin
            pc <= 8'h00; hi_reg <= 64'd0; lo_reg <= 64'd0; status_reg <= 4'b0;
        end else begin
            pc <= pc_next;
            if (update_sr) begin
                status_reg <= {overflow_f, carry_f, neg_f, zero_f};
            end
            if (write_hi_lo) begin
                lo_reg <= {32'd0, alu_result[31:0]};
                hi_reg <= {32'd0, alu_result[63:32]};
            end
        end
    end
endmodule