`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    13:56:47 01/03/2026 
// Design Name: 
// Module Name:    data_memory 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

module data_memory(
    input clk,
    input mem_write_en,
    input mem_read_en,
    input [15:0] address,
    input [15:0] write_data,
    output [15:0] read_data
    );

    // A small RAM of 256 words, each 16-bits wide
    reg [15:0] ram [0:255];
.
    integer i;

    // Combinational Read
    assign read_data = (mem_read_en) ? ram[address] : 16'bz;

    // Sequential Write
    always @(posedge clk)
    begin
        if (mem_write_en)
        begin
            ram[address] <= write_data;
        end
    end

    // This block runs only once at the very beginning of the simulation (t=0)
    // to initialize the memory contents to zero.
    initial begin
        for (i = 0; i < 256; i = i + 1) begin
            ram[i] = 16'd0;
        end
    end

endmodule