`timescale 1ns / 1ps

module testbench;
    reg clk;
    reg reset;
    processor uut (.clk(clk), .reset(reset));

    initial begin
        clk = 0;
        forever #10 clk = ~clk;
    end
      
    initial begin
        reset = 1;
        #25;
        reset = 0;

        $monitor("Time=%0t ns, PC=%d, R1=%d, R2=%d, R3=%d, R4=%d, R5=%x, R6=%x, Hi=%d, Lo=%d, SR=%b",
                 $time, uut.pc, uut.rf.registers[1], uut.rf.registers[2],
                 uut.rf.registers[3], uut.rf.registers[4], uut.rf.registers[5],
                 uut.rf.registers[6], uut.hi_reg, uut.lo_reg, uut.status_reg);
                 
         #200;
        $finish;
    end
endmodule