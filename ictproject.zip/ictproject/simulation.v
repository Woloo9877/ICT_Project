`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:    13:59:32 01/03/2026 
// Design Name: 
// Module Name:    simulation 
// Project Name: 
// Target Devices: 
// Tool versions: 
// Description: 
//
// Dependencies: 
//
// Revision: 
// Revision 0.01 - File Created
// Additional Comments: 
//
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ps

module testbench;

    // Inputs
    reg clk;
    reg reset;

    // Instantiate the processor
    processor uut (
        .clk(clk), 
        .reset(reset)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #10 clk = ~clk; // Create a clock with 20ns period
    end
      
    // Test sequence
    initial begin
        // Apply reset
        reset = 1;
        #25;
        reset = 0;

        // Run simulation for a while
        #200;
        
        // Stop the simulation
        $finish;
    end
      
endmodule