`timescale 1ns / 1ps

module instruction_memory(
    input [7:0] address,
    output reg [19:0] instruction
    );
    
    // R-Type Format: {Opcode[19:15], Rd[14:12], Rs[11:9], Rt[8:6], Unused[5:0]}
    always @(*)
    begin
        case(address)
            // 0: LI R1, 7
            8'h00: instruction = {5'b00110, 3'b001, 3'b000, 9'd7};
            
            // 1: LI R2, 6
            8'h01: instruction = {5'b00110, 3'b010, 3'b000, 9'd6};
            
            // 2: MUL R1, R2
            8'h02: instruction = {5'b01101, 3'b000, 3'b001, 3'b010, 6'b0}; // Correct 20-bit encoding
            
            // 3: NOP (Stall for data hazard)
            8'h03: instruction = 20'b0;
            
            // 4: MFLO R3
            8'h04: instruction = {5'b01110, 3'b011, 3'b000, 3'b000, 6'b0}; // Correct 20-bit encoding
            
            // 5: J 8
            8'h05: instruction = {5'b01001, 15'd8};
            
            // 6: This instruction is skipped by the jump
            8'h06: instruction = 20'b0;
            
            // 7: This instruction is skipped by the jump
            8'h07: instruction = 20'b0;
            
            // 8: VMUL R1, R2
            8'h08: instruction = {5'b10000, 3'b001, 3'b001, 3'b010, 6'b0}; // Correct 20-bit encoding
            
            default: instruction = 20'b0;
        endcase
    end
endmodule