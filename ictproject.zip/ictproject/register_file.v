`timescale 1ns / 1ps

module register_file(
    input clk,
    input reset,
    input reg_write_en,
    input [2:0] read_addr1,
    input [2:0] read_addr2,
    input [2:0] write_addr,
    input [63:0] write_data,
    output [63:0] read_data1,
    output [63:0] read_data2,
    // --- New inputs for VLW ---
    input lane_write_en,
    input [1:0] lane_id,
    input [63:0] mem_data_in
    );

    reg [63:0] registers [0:7];
    integer i;

    assign read_data1 = registers[read_addr1];
    assign read_data2 = registers[read_addr2];

    always @(posedge clk or posedge reset)
    begin
        if (reset) begin
            for (i = 0; i < 8; i = i + 1) begin
                registers[i] <= 64'd0;
            end
        end
        else if (reg_write_en) begin // Normal write operation
            registers[write_addr] <= write_data;
        end
        else if (lane_write_en) begin
            case(lane_id)
                2'b00: registers[write_addr][15:0] <= mem_data_in[15:0];
                2'b01: registers[write_addr][31:16] <= mem_data_in[15:0];
                2'b10: registers[write_addr][47:32] <= mem_data_in[15:0];
                2'b11: registers[write_addr][63:48] <= mem_data_in[15:0];
            endcase
        end
    end
endmodule